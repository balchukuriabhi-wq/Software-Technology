import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 60
NODE_HEIGHT = 40
HORIZONTAL_GAP = 40
CANVAS_HEIGHT = 120
CANVAS_WIDTH = 900

# ── Data structure ────────────────────────────────────────────────────────────

class Node:
    """A single node in a singly linked list (next pointer only)."""
    def __init__(self, data):
        self.data = data
        self.next = None          # No .prev — this is a singly linked list


class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert_at_index(self, data, index):
        """Insert a new node with *data* at position *index* (0-based)."""
        new_node = Node(data)

        # Insert at head
        if index == 0:
            new_node.next = self.head
            self.head = new_node
            return True

        # Walk to the node just before the target index
        current = self.head
        count = 0
        while current and count < index - 1:
            current = current.next
            count += 1

        if current is None:
            return False          # Index out of range

        # Splice the new node in
        new_node.next = current.next
        current.next = new_node
        return True

    def delete_value(self, value):
        """Remove the first node whose data equals *value*."""
        current = self.head

        # Deleting the head
        if current and current.data == value:
            self.head = current.next
            return True

        # Walk the rest of the list
        while current and current.next:
            if current.next.data == value:
                current.next = current.next.next   # unlink target node
                return True
            current = current.next

        return False              # Value not found

    def search(self, value):
        """Return the 0-based index of the first node with *value*, or -1."""
        current = self.head
        index = 0
        while current:
            if current.data == value:
                return index
            current = current.next
            index += 1
        return -1

    def to_list(self):
        """Return a plain Python list of node values (head → tail)."""
        arr = []
        current = self.head
        while current:
            arr.append(current.data)
            current = current.next
        return arr


# ── Visualiser ────────────────────────────────────────────────────────────────

class SinglyLinkedListVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Singly Linked List Visualizer")

        self.sll = SinglyLinkedList()

        # ── Canvas ────────────────────────────────────────────────────────────
        self.canvas = tk.Canvas(
            root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="white"
        )
        self.canvas.pack(pady=20)

        # ── Controls ──────────────────────────────────────────────────────────
        control_frame = tk.Frame(root)
        control_frame.pack()

        # Insert row
        tk.Label(control_frame, text="Insert Value:").grid(row=0, column=0)
        self.insert_value_entry = tk.Entry(control_frame, width=5)
        self.insert_value_entry.grid(row=0, column=1)

        tk.Label(control_frame, text="at Index:").grid(row=0, column=2)
        self.insert_index_entry = tk.Entry(control_frame, width=5)
        self.insert_index_entry.grid(row=0, column=3)

        tk.Button(control_frame, text="Insert", command=self.insert_node).grid(
            row=0, column=4, padx=10
        )

        # Delete row
        tk.Label(control_frame, text="Delete Value:").grid(row=1, column=0)
        self.delete_value_entry = tk.Entry(control_frame, width=5)
        self.delete_value_entry.grid(row=1, column=1)
        tk.Button(control_frame, text="Delete", command=self.delete_node).grid(
            row=1, column=4, padx=10
        )

        # Search row
        tk.Label(control_frame, text="Search Value:").grid(row=2, column=0)
        self.search_value_entry = tk.Entry(control_frame, width=5)
        self.search_value_entry.grid(row=2, column=1)
        tk.Button(control_frame, text="Search", command=self.search_node).grid(
            row=2, column=4, padx=10
        )

        # Status bar
        self.status_label = tk.Label(root, text="", font=("Arial", 12), fg="blue")
        self.status_label.pack(pady=10)

        self.draw_list()

    # ── Drawing helpers ───────────────────────────────────────────────────────

    def draw_node(self, x, y, data, highlight=False):
        fill_color = "yellow" if highlight else "lightgrey"
        outline_color = "red" if highlight else "black"

        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill=fill_color, outline=outline_color, width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH // 2, y + NODE_HEIGHT // 2,
            text=str(data), font=("Arial", 16)
        )

    def draw_arrow(self, x1, y1, x2, y2):
        """Single forward arrow (→) between two nodes."""
        self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST, width=2)

    def draw_list(self, highlight_index=None):
        self.canvas.delete("all")
        nodes = self.sll.to_list()
        x = 20
        y = 40

        centers = []

        # Draw all nodes
        for i, val in enumerate(nodes):
            self.draw_node(x, y, val, highlight=(i == highlight_index))
            centers.append((x + NODE_WIDTH // 2, y + NODE_HEIGHT // 2))
            x += NODE_WIDTH + HORIZONTAL_GAP

        # Draw a single forward arrow between consecutive nodes
        for i in range(len(centers) - 1):
            x1, y1 = centers[i]
            x2, y2 = centers[i + 1]
            # Leave a small gap on each side of the arrow so it doesn't overlap the rectangles
            self.draw_arrow(x1 + NODE_WIDTH // 2, y1, x2 - NODE_WIDTH // 2, y2)



    # ── Button callbacks ──────────────────────────────────────────────────────

    def insert_node(self):
        try:
            val = int(self.insert_value_entry.get())
            index = int(self.insert_index_entry.get())
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid integers for value and index.")
            return
        if index < 0:
            messagebox.showerror("Input Error", "Index must be non-negative.")
            return
        success = self.sll.insert_at_index(val, index)
        if not success:
            messagebox.showerror("Index Error", "Index out of range.")
            return
        self.status_label.config(text=f"Inserted {val} at index {index}")
        self.draw_list()

    def delete_node(self):
        try:
            val = int(self.delete_value_entry.get())
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid integer value to delete.")
            return
        success = self.sll.delete_value(val)
        if success:
            self.status_label.config(text=f"Deleted value {val} from the list")
            self.draw_list()
        else:
            messagebox.showinfo("Not Found", f"Value {val} not found.")

    def search_node(self):
        try:
            val = int(self.search_value_entry.get())
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid integer value to search.")
            return

        nodes = self.sll.to_list()

        def highlight_next(i=0):
            if i > 0:
                self.draw_list()
            if i < len(nodes):
                self.draw_list(highlight_index=i)
                if nodes[i] == val:
                    self.status_label.config(text=f"Value {val} found at index {i}")
                    return
                self.root.after(500, lambda: highlight_next(i + 1))
            else:
                self.status_label.config(text=f"Value {val} not found in the list")
                self.draw_list()

        highlight_next()


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    root = tk.Tk()
    app = SinglyLinkedListVisualizer(root)

    # Pre-populate with some values
    for v in [10, 20, 30, 40]:
        app.sll.insert_at_index(v, app.sll.search(v) + 1 if app.sll.search(v) != -1 else 100)
    app.draw_list()

    root.mainloop()