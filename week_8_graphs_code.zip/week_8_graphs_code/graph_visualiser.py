from graph import Graph
import tkinter as tk
import math

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph
        self.canvas = tk.Canvas(self, width=400, height=400, bg="white")
        self.canvas.pack()  

        self.vertex_positions = {}
        self.vertex_circles = {}

        button_frame = tk.Frame(self)
        button_frame.pack(pady=5)

        tk.Button(button_frame, text="Add Vertex", command=self.add_vertex).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Remove Vertex", command=self.remove_vertex).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Add Edge", command=self.add_edge).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Run BFS", command=self.run_bfs).pack(side=tk.LEFT, padx=5)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()

        radius = 20
        spacing = 100
        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 200, 200

        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)

            circle = self.canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius,
                fill="lightblue"
            )
            self.vertex_circles[v] = circle
            self.canvas.create_text(x, y, text=v)

        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]
                self.canvas.create_line(
                    x1, y1, x2, y2,
                    arrow=tk.LAST if self.graph.directed else None
                )

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), "")
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")

    def add_vertex(self):
        new_vertex = chr(ord('A') + len(self.graph.graph))
        self.graph.add_vertex(new_vertex)
        self.draw_graph()

    def remove_vertex(self):
        if self.graph.graph:
            last_vertex = list(self.graph.graph.keys())[-1]
            self.graph.remove_vertex(last_vertex)
            self.draw_graph()

    def add_edge(self):
        vertices = list(self.graph.graph.keys())
        if len(vertices) >= 2:
            v1 = vertices[0]
            v2 = vertices[-1]
            if self.graph.weighted:
                self.graph.add_edge(v1, v2, 5)
            else:
                self.graph.add_edge(v1, v2)
            self.draw_graph()

    def run_bfs(self):
        if not self.graph.graph:
            return

        for circle in self.vertex_circles.values():
            self.canvas.itemconfig(circle, fill="lightblue")

        start_vertex = list(self.graph.graph.keys())[0]
        order = self.graph.bfs(start_vertex)

        delay = 0
        for vertex in order:
            self.after(delay, lambda v=vertex: self.canvas.itemconfig(self.vertex_circles[v], fill="orange"))
            delay += 500


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    app = GraphVisualizer(g)
    app.mainloop()