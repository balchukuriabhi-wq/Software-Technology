from graph import Graph
import tkinter as tk
import math
import time
import threading


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry("650x700")
        self.graph = graph

        self.canvas = tk.Canvas(self, width=600, height=600, bg="white")
        self.canvas.pack(pady=10)

        self.vertex_positions = {}
        self.vertex_circles = {}
        self.edge_lines = {}
        self.node_radius = 20
        self.spacing = 180
        self.center = (300, 300)

        control_frame = tk.Frame(self)
        control_frame.pack()

        tk.Button(control_frame, text="Run BFS",
                command=lambda: self.run_traversal("bfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Run DFS",
                command=lambda: self.run_traversal("dfs")).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Undirected Cycle",
                command=self.run_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Detect Directed Cycle",
                command=self.run_directed_cycle_detection).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Reset Colors",
                command=self.reset_colors).pack(side=tk.LEFT, padx=5)

        self.info_label = tk.Label(self, text="")
        self.info_label.pack(pady=5)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()
        self.edge_lines.clear()

        vertices = list(self.graph.graph.keys())
        if not vertices:
            return

        cx, cy = self.center
        angle_gap = 360 / len(vertices)

        for i, vertex in enumerate(vertices):
            angle = math.radians(i * angle_gap)
            x = cx + self.spacing * math.cos(angle)
            y = cy + self.spacing * math.sin(angle)
            self.vertex_positions[vertex] = (x, y)

        for v in vertices:
            x, y = self.vertex_positions[v]
            circle_id = self.canvas.create_oval(
                x - self.node_radius, y - self.node_radius,
                x + self.node_radius, y + self.node_radius,
                fill="lightblue", outline="black", width=2
            )
            self.vertex_circles[v] = circle_id
            self.canvas.create_text(x, y, text=v, font=("Arial", 12, "bold"))

        drawn_undirected_edges = set()

        for v in vertices:
            x1, y1 = self.vertex_positions[v]

            for nbr in self.graph.graph[v]:
                if not self.graph.directed:
                    edge_key = tuple(sorted((v, nbr)))
                    if edge_key in drawn_undirected_edges:
                        continue
                    drawn_undirected_edges.add(edge_key)

                x2, y2 = self.vertex_positions[nbr]
                dx, dy = x2 - x1, y2 - y1
                dist = math.sqrt(dx * dx + dy * dy)
                if dist == 0:
                    continue

                offset_x = dx / dist * self.node_radius
                offset_y = dy / dist * self.node_radius

                start_x = x1 + offset_x
                start_y = y1 + offset_y
                end_x = x2 - offset_x
                end_y = y2 - offset_y

                line_id = self.canvas.create_line(
                    start_x, start_y, end_x, end_y,
                    arrow=tk.LAST if self.graph.directed else None,
                    width=2
                )

                if self.graph.directed:
                    self.edge_lines[(v, nbr)] = line_id
                else:
                    self.edge_lines[(v, nbr)] = line_id
                    self.edge_lines[(nbr, v)] = line_id

                if self.graph.weighted:
                    weight = self.graph.weights.get((v, nbr), "")
                    mid_x = (start_x + end_x) / 2
                    mid_y = (start_y + end_y) / 2
                    self.canvas.create_text(
                        mid_x, mid_y,
                        text=str(weight),
                        fill="red",
                        font=("Arial", 10, "italic")
                    )

    def reset_colors(self):
        for circle_id in self.vertex_circles.values():
            self.canvas.itemconfig(circle_id, fill="lightblue")
        for edge_id in set(self.edge_lines.values()):
            self.canvas.itemconfig(edge_id, fill="black", width=2)
        self.info_label.config(text="")

    def highlight_vertex(self, vertex, color):
        circle_id = self.vertex_circles.get(vertex)
        if circle_id:
            self.canvas.itemconfig(circle_id, fill=color)
            self.update()

    def highlight_edge(self, v1, v2, color):
        line_id = self.edge_lines.get((v1, v2))
        if line_id:
            self.canvas.itemconfig(line_id, fill=color, width=3)
            self.update()

    def run_traversal(self, method):
        def worker():
            self.reset_colors()

            start_vertex = "A" if "A" in self.graph.graph else next(iter(self.graph.graph), None)
            if start_vertex is None:
                self.info_label.config(text="Graph is empty")
                return

            visited = set()
            order = []

            if method == "bfs":
                self.info_label.config(text="Running BFS...")
                queue = [start_vertex]

                while queue:
                    vertex = queue.pop(0)
                    if vertex not in visited:
                        visited.add(vertex)
                        order.append(vertex)
                        self.highlight_vertex(vertex, "orange")
                        self.info_label.config(text=f"BFS visiting: {vertex}")
                        time.sleep(0.6)

                        for nbr in self.graph.graph[vertex]:
                            if nbr not in visited and nbr not in queue:
                                queue.append(nbr)
                                self.highlight_edge(vertex, nbr, "green")
                                time.sleep(0.2)

                self.info_label.config(text=f"BFS complete: {' -> '.join(order)}")

            elif method == "dfs":
                self.info_label.config(text="Running DFS...")
                stack = [start_vertex]

                while stack:
                    vertex = stack.pop()
                    if vertex not in visited:
                        visited.add(vertex)
                        order.append(vertex)
                        self.highlight_vertex(vertex, "purple")
                        self.info_label.config(text=f"DFS visiting: {vertex}")
                        time.sleep(0.6)

                        for nbr in reversed(self.graph.graph[vertex]):
                            if nbr not in visited:
                                stack.append(nbr)
                                self.highlight_edge(vertex, nbr, "blue")
                                time.sleep(0.2)

                self.info_label.config(text=f"DFS complete: {' -> '.join(order)}")

        threading.Thread(target=worker, daemon=True).start()

    def run_cycle_detection(self):
        def worker():
            self.reset_colors()

            if self.graph.directed:
                self.info_label.config(text="Undirected cycle detection works only on undirected graphs.")
                return

            self.info_label.config(text="Detecting cycles in undirected graph...")
            visited = set()

            def cycle_dfs(current, parent):
                visited.add(current)
                self.highlight_vertex(current, "yellow")
                time.sleep(0.5)

                for nbr in self.graph.graph[current]:
                    if nbr not in visited:
                        self.highlight_edge(current, nbr, "orange")
                        time.sleep(0.3)
                        if cycle_dfs(nbr, current):
                            self.highlight_vertex(current, "red")
                            self.highlight_vertex(nbr, "red")
                            self.highlight_edge(current, nbr, "red")
                            return True
                    elif nbr != parent:
                        self.highlight_vertex(current, "red")
                        self.highlight_vertex(nbr, "red")
                        self.highlight_edge(current, nbr, "red")
                        return True

                return False

            for vertex in self.graph.graph:
                if vertex not in visited:
                    if cycle_dfs(vertex, None):
                        self.info_label.config(text="Cycle detected in the undirected graph!")
                        return

            self.info_label.config(text="No cycles found in the undirected graph.")

        threading.Thread(target=worker, daemon=True).start()

    def run_directed_cycle_detection(self):
        def worker():
            self.reset_colors()

            if not self.graph.directed:
                self.info_label.config(text="Directed cycle detection works only on directed graphs.")
                return

            self.info_label.config(text="Detecting cycles in directed graph...")
            visited = set()
            rec_stack = set()

            def dfs(vertex):
                visited.add(vertex)
                rec_stack.add(vertex)
                self.highlight_vertex(vertex, "yellow")
                time.sleep(0.5)

                for nbr in self.graph.graph[vertex]:
                    if nbr not in visited:
                        self.highlight_edge(vertex, nbr, "orange")
                        time.sleep(0.3)
                        if dfs(nbr):
                            self.highlight_vertex(vertex, "red")
                            self.highlight_vertex(nbr, "red")
                            self.highlight_edge(vertex, nbr, "red")
                            return True
                    elif nbr in rec_stack:
                        self.highlight_vertex(vertex, "red")
                        self.highlight_vertex(nbr, "red")
                        self.highlight_edge(vertex, nbr, "red")
                        return True

                rec_stack.remove(vertex)
                return False

            for vertex in self.graph.graph:
                if vertex not in visited:
                    if dfs(vertex):
                        self.info_label.config(text="Cycle detected in the directed graph!")
                        return

            self.info_label.config(text="No cycles found in the directed graph.")

        threading.Thread(target=worker, daemon=True).start()


def build_undirected_demo_graph():
    g = Graph(directed=False, weighted=False)
    for v in ["A", "B", "C", "D"]:
        g.add_vertex(v)
    g.add_edge("A", "B")
    g.add_edge("B", "C")
    g.add_edge("C", "A")
    g.add_edge("C", "D")
    return g


def build_directed_demo_graph():
    g = Graph(directed=True, weighted=False)
    for v in ["A", "B", "C", "D"]:
        g.add_vertex(v)
    g.add_edge("A", "B")
    g.add_edge("B", "C")
    g.add_edge("C", "A")
    g.add_edge("C", "D")
    return g


if __name__ == "__main__":
    app = GraphVisualizer(build_directed_demo_graph())
    app.mainloop()