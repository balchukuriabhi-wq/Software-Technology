from tkinter import *

class SierpinskiTriangle:
    def __init__(self):
        main_window = Tk()
        main_window.title("Sierpinski Triangle")
        self.canvas_width = 400
        self.canvas_height = 400
        self.drawing_canvas = Canvas(main_window, width=self.canvas_width, height=self.canvas_height)
        self.drawing_canvas.pack()
        control_frame = Frame(main_window)
        control_frame.pack()
        Label(control_frame, text="Enter an order: ").pack(side=LEFT)
        self.fractal_order = StringVar()
        Entry(control_frame, textvariable=self.fractal_order, justify=RIGHT).pack(side=LEFT)
        Button(control_frame, text="Display Sierpinski Triangle", command=self.render).pack(side=LEFT)
        main_window.mainloop()

    def render(self):
        depth = int(self.fractal_order.get())
        self.drawing_canvas.delete("line")
        apex = [self.canvas_width / 2, 10]
        bottom_left = [10, self.canvas_height - 10]
        bottom_right = [self.canvas_width - 10, self.canvas_height - 10]
        self.draw_fractal(depth, apex, bottom_left, bottom_right)

    def draw_fractal(self, depth, apex, bottom_left, bottom_right):
        if depth == 0:
            self.draw_edge(apex, bottom_left)
            self.draw_edge(bottom_left, bottom_right)
            self.draw_edge(bottom_right, apex)
        else:
            mid_left = self.get_midpoint(apex, bottom_left)
            mid_bottom = self.get_midpoint(bottom_left, bottom_right)
            mid_right = self.get_midpoint(bottom_right, apex)
            self.draw_fractal(depth - 1, apex, mid_left, mid_right)
            self.draw_fractal(depth - 1, mid_left, bottom_left, mid_bottom)
            self.draw_fractal(depth - 1, mid_right, mid_bottom, bottom_right)

    def draw_edge(self, start_point, end_point):
        self.drawing_canvas.create_line(start_point[0], start_point[1], end_point[0], end_point[1], tags="line")

    def get_midpoint(self, start_point, end_point):
        return [(start_point[0] + end_point[0]) / 2, (start_point[1] + end_point[1]) / 2]

SierpinskiTriangle()