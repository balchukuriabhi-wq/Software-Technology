# TowerOfHanoi.py
move_counter = 0  # Global variable to count moves

def main():
    global move_counter
    num_disks = int(input("Enter number of disks: "))
    print("The moves are:")
    move_disks(num_disks, 'A', 'B', 'C')
    print("Number of moves is", move_counter)

def move_disks(disk_count, source_tower, target_tower, spare_tower):
    global move_counter
    if disk_count == 1:
        move_counter += 1
        print(f"Move disk 1 from {source_tower} to {target_tower}")
        return
    move_disks(disk_count - 1, source_tower, spare_tower, target_tower)
    move_counter += 1
    print(f"Move disk {disk_count} from {source_tower} to {target_tower}")
    move_disks(disk_count - 1, spare_tower, target_tower, source_tower)

main()